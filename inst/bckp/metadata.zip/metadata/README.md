A repository for various files of the project.
